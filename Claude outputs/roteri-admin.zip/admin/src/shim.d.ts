declare module 'react-dom/client' { export function createRoot(el: Element): { render(node: import('react').ReactNode): void }; }
declare const process: { env: Record<string, string | undefined> };
declare module '*.css';
